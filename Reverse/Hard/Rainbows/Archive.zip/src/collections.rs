use crate::consts;
use rand::Rng;

#[derive(Clone)]
pub struct ColorEncryption {
    pub character: char,
    collection_numbers: Vec<u32>,
    indexer: usize,
    indexer_step: i32,
}

impl ColorEncryption {
    pub fn new(character: char) -> ColorEncryption {
        let possible_combination: Vec<u32> = consts::generate_collection(character);
        let indexer = rand::thread_rng().gen_range(0..possible_combination.len() - 1);

        ColorEncryption {
            character,
            collection_numbers: possible_combination,
            indexer,
            indexer_step: 1,
        }
    }

    pub fn step(&mut self) {
        if self.indexer == self.collection_numbers.len() - 1 {
            self.indexer_step = -1;
        }

        if self.indexer == 0 {
            self.indexer_step = 1;
        }

        // to get around the usize limitations
        self.indexer = (self.indexer as i32 + self.indexer_step) as usize;
    }

    pub fn return_number(&mut self) -> u32 {
        self.collection_numbers[self.indexer]
    }
}
