mod collections;
mod consts;

use std::io::Write;

use colored::Colorize;

use collections::ColorEncryption;
use consts::generate_colors;

fn print_banner() {
    println!(
        r#"
                Art By John Stark

                 .##@@&&&@@##.
              ,##@&::%&&%%::&@##.
             #@&:%%000000000%%:&@#
           #@&:%00'         '00%:&@#
          #@&:%0'             '0%:&@#
         #@&:%0                 0%:&@#
        #@&:%0                   0%:&@#
        #@&:%0                   0%:&@#
        "" ' "                   " ' ""
      _oOoOoOo_                   .-.-.
     (oOoOoOoOo)                 (  :  )
      )`"""""`(                .-.`. .'.-.
     /         \              (_  '.Y.'  _)
    | #         |             (   .'|'.   )
    \           /              '-'  |  '-'
     `=========`

              No Homo by SlamZDank
    "#
    );
    println!("\n");
}

fn main() {
    print_banner();

    let mut list_of_color_encryption: Vec<ColorEncryption> = Vec::new();
    let string = consts::get_flag();
    for character in string.unwrap().chars() {
        // to find the last index of the character
        if let Some(index) = list_of_color_encryption
            .iter()
            .rposition(|color_from_the_list| {
                color_from_the_list
                    .character
                    .eq_ignore_ascii_case(&character)
            })
        {
            let mut cloned_color_encryption = list_of_color_encryption[index].clone();
            cloned_color_encryption.step();
            list_of_color_encryption.push(cloned_color_encryption);
        } else {
            let color_encryption = ColorEncryption::new(character);
            list_of_color_encryption.push(color_encryption);
        }
    }

    for mut color_encryption in list_of_color_encryption {
        std::io::stdout().flush().unwrap();
        let colored_hex: String = format!(
            "#{:06x}",
            &generate_colors(color_encryption.return_number())
        );

        let (r, g, b) = (
            u8::from_str_radix(&colored_hex[1..3], 16).unwrap(),
            u8::from_str_radix(&colored_hex[3..5], 16).unwrap(),
            u8::from_str_radix(&colored_hex[5..7], 16).unwrap(),
        );

        print!(
            "{}",
            format!("{:b}", color_encryption.return_number())
                .as_str()
                .truecolor(r, g, b)
        ); // this got me running in a doozey
    }
}
